# Simulation Supplementary Data

This folder contains simulation data used in the paper

> Yuki Takazawa, Atsushi Takeda, Momoko Hayamizu, and Olivier Gascuel. Outperforming the Majority-Rule Consensus Tree Using Fine-Grained Dissimilarity Measures, submitted.

## Scenario mapping

- `scn_a`: tree_height = 0.05, seq_len = 100
- `scn_b`: tree_height = 0.5, seq_len = 100
- `scn_c`: tree_height = 0.05, seq_len = 300
- `scn_d`: tree_height = 0.5, seq_len = 300

## Directory tree

```text
simulation/
└── scn_{a,b,c,d}/
    └── repN/
        ├── true_tree.tre
        ├── alignment.fasta
        └── alignment.nex
```

- Each scenario has `rep0` to `rep99`.
- `true_tree.tre` is the birth-death simulated true tree.
- `alignment.fasta` and `alignment.nex` are the simulated MSAs.
