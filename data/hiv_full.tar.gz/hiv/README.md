# HIV Supplementary Data

This folder contains HIV benchmark data used in the paper

> Yuki Takazawa, Atsushi Takeda, Momoko Hayamizu, and Olivier Gascuel. Outperforming the Majority-Rule Consensus Tree Using Fine-Grained Dissimilarity Measures, submitted.

## Data provenance

- The alignment (`hiv.fa`) and maximum-likelihood tree(`mle.tre`) are taken from Lemoine et al. (2018).
- The alignment file is included for completeness but was not used directly in the paper.

- Reference study: Lemoine F., Domelevo Entfellner J.B., Wilkinson E., Correia D., Dávila Felipe M., De Oliveira T., Gascuel O. 2018. Renewing Felsenstein’s phylogenetic bootstrap in the era of big data. Nature. 556:452–456.
- Original source data: https://github.com/evolbioinfo/booster-workflows/releases/tag/v0.1.0
