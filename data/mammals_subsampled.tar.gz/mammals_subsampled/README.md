# Mammals Supplementary Data

This folder contains mammals subsampled data used in the paper

> Yuki Takazawa, Atsushi Takeda, Momoko Hayamizu, and Olivier Gascuel. Outperforming the Majority-Rule Consensus Tree Using Fine-Grained Dissimilarity Measures, submitted.

## Data provenance

- The full alignment and NCBI taxonomy reference tree taken from Lemoine et al. (2018) was used to construct this subsampled dataset (`rep0` to `rep99`).

- Reference study: Lemoine F., Domelevo Entfellner J.B., Wilkinson E., Correia D., Dávila Felipe M., De Oliveira T., Gascuel O. 2018. Renewing Felsenstein’s phylogenetic bootstrap in the era of big data. Nature. 556:452–456.
- Original source data: https://github.com/evolbioinfo/booster-workflows/releases/tag/v0.1.0

## Directory tree

```text
mammals/
└── subsampled/
    └── repN/
        ├── ncbi_tree.tre # subsampled ncbi tree
        └── alignment.fasta # subsampled alignment
```
